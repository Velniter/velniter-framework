<form method="post" action="<?= base_url() ?>test_upload" enctype="multipart/form-data">
	<input type="file" name="file">
	<input type="submit">
</form>