<?php

	const base_url 			= 'http://localhost/GudFramework-psr4/';
	
	// Tambahin ajah
