<?php

	const pusher_api_key 	= '';
	const pusher_secret_key = '';
	const pusher_app_key 	= '';
	const pusher_cluster  	= 'ap1';
	const pusher_tls  		= true;