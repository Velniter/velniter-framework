<?php
	
	/* Login true redirect  */
	const logged_in_true 	= '/';
	
	/* Login false redirect */
	const logged_in_false 	= 'login';