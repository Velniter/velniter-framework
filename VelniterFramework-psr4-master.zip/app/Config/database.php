<?php
	
	const db_name = 'api_onlineshop';
	const db_host = 'localhost';
	const db_user = 'root';
	const db_pass = '';