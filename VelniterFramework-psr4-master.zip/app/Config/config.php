<?php

	const base_url 			= 'Your url directory';
	
	// Tambahin ajah
